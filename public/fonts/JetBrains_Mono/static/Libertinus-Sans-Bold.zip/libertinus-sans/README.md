Libertinus fonts
================

Libertinus fonts is a fork of the Linux Libertine and Linux Biolinum fonts that
started as an OpenType math companion of the Libertine font family, but grown
as a full fork to address some of the bugs in the fonts.

The family consists of:

* Libertinus Serif: forked from *Linux Libertine*.
* Libertinus Sans: forked from *Linux Biolinum*.
* Libertinus Mono: forked from *Linux Libertine Mono*.
* Libertinus Math: an OpenType math font for use in OpenType math-capable
  applications like LuaTeX, XeTeX or MS Word 2007+.

Libertinus fonts are available under the terms of Open Font License version
1.1.
